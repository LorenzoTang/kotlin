//name: Tang Le, Student ID: 201912989
// Task 2.3
fun main() {
    val myAge = 29u
    val universeAge = 13_800_000_000L
    val status = 'M'
    val name = "Sarah"
    val height = 1.78f
    val root2 = Math.sqrt(2.0)

    println(myAge)
    println(universeAge)
    println(status)
    println(name)
    println(height)
    println(root2)
}
