// Task 4.2: use of if and ranges
//Name: Tang Le 
//ID: 201912989 
fun main() {
    // Add your code here
    println("Pizza menu")
    println("(a). Margherita")
    println("(b). Quattro Stagioni")
    println("(c). Seafood")
    println("(d). Hawaiian")

    println("Please choose your pizza (a-d): ")

    val choice = readln().lowercase()

    if (choice.length == 1 && choice[0] in 'a'..'d') {
       println("Order accepted")
        
    } else {
        println("Invalid choice. Please choose a valid option (a-d).")
    }
}
